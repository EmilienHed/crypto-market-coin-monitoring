import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-stats',
  templateUrl: './stats.page.html',
  styleUrls: ['./stats.page.scss'],
})
export class StatsPage implements OnInit {
  cryptoId: string | null = null;
  cryptoData: any;

  constructor(private route: ActivatedRoute, private http: HttpClient) {}

  ngOnInit() {
    this.cryptoId = this.route.snapshot.paramMap.get('id');
    if (this.cryptoId) {
      this.getCryptoData();
    }
  }

  getCryptoData() {
    const url = `https://api.coingecko.com/api/v3/coins/${this.cryptoId}`;
    this.http.get(url).subscribe((data) => {
      this.cryptoData = data;
      console.log(this.cryptoData); // Vérifier les données dans la console
    });
  }
}
