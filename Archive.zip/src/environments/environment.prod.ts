export const environment = {
  production: true,
  title: 'Production Environment Heading',
  apiURL: 'https://api.coingecko.com/api/v3/coins/list'
};
